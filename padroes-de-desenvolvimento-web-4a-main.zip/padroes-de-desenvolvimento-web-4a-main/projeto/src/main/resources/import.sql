insert into Categoria (nome) values ('Frutas');
insert into Categoria (nome) values ('Bebidas');
insert into Categoria (nome) values ('Carnes');

insert into Fabricante (nome) values ('The Coca-Cola Company');

insert into Produto (nome, preco, quantidade, validade, categoria_codigo, fabricante_codigo) values ('Coca Cola 2 Litros', 12.00, 15, '2025-12-20', 2, 1);
